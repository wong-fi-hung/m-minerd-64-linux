#!/bin/bash

./m-minerd -o stratum+tcp://mining.m-hash.com:3334 -u magiminer.user -p pass -e 60
